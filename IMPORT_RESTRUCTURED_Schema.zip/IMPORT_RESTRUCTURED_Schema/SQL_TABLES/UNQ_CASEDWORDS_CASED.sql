--------------------------------------------------------
--  DDL for Index UNQ_CASEDWORDS_CASED
--------------------------------------------------------

  CREATE UNIQUE INDEX "UNQ_CASEDWORDS_CASED" ON "CASEDWORDS" ("CASED") ;
