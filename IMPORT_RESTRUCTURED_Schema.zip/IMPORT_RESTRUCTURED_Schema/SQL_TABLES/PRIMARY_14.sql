--------------------------------------------------------
--  DDL for Index PRIMARY_14
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_14" ON "VFRAMES" ("FRAMEID") ;
