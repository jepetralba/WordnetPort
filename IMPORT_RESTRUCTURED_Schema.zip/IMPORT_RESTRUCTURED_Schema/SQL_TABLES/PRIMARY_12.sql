--------------------------------------------------------
--  DDL for Index PRIMARY_12
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_12" ON "SYNSETS" ("SYNSETID") ;
