--------------------------------------------------------
--  Constraints for Table MORPHS
--------------------------------------------------------

  ALTER TABLE "MORPHS" MODIFY ("MORPHID" NOT NULL ENABLE);
  ALTER TABLE "MORPHS" MODIFY ("MORPH" NOT NULL ENABLE);
  ALTER TABLE "MORPHS" ADD CONSTRAINT "PRIMARY_7" PRIMARY KEY ("MORPHID") ENABLE;
