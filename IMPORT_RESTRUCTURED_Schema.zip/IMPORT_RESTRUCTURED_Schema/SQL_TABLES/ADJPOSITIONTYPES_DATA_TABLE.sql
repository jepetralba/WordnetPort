REM INSERTING into ADJPOSITIONTYPES
SET DEFINE OFF;
Insert into ADJPOSITIONTYPES (POSITION,POSITIONNAME) values ('a','attributive');
Insert into ADJPOSITIONTYPES (POSITION,POSITIONNAME) values ('p','predicate');
Insert into ADJPOSITIONTYPES (POSITION,POSITIONNAME) values ('ip','immediately postnominal');
