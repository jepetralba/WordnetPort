--------------------------------------------------------
--  DDL for Table VFRAMEMAPS
--------------------------------------------------------

  CREATE TABLE "VFRAMEMAPS" ("SYNSETID" NUMBER(10,0) DEFAULT '0', "WORDID" NUMBER(12,0) DEFAULT '0', "FRAMEID" NUMBER(3,0) DEFAULT '0') ;
