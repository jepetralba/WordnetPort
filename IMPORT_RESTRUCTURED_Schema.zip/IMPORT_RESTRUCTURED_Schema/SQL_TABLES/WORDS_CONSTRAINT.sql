--------------------------------------------------------
--  Constraints for Table WORDS
--------------------------------------------------------

  ALTER TABLE "WORDS" MODIFY ("WORDID" NOT NULL ENABLE);
  ALTER TABLE "WORDS" MODIFY ("LEMMA" NOT NULL ENABLE);
  ALTER TABLE "WORDS" ADD CONSTRAINT "PRIMARY_1" PRIMARY KEY ("WORDID") ENABLE;
