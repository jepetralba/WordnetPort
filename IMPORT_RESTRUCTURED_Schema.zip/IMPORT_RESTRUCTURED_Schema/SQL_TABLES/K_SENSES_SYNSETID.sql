--------------------------------------------------------
--  DDL for Index K_SENSES_SYNSETID
--------------------------------------------------------

  CREATE INDEX "K_SENSES_SYNSETID" ON "SENSES" ("SYNSETID") ;
