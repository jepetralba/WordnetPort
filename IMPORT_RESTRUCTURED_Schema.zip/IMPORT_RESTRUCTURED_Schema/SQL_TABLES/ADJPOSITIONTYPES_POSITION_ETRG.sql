--------------------------------------------------------
--  DDL for Trigger ADJPOSITIONTYPES_POSITION_ETRG
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "ADJPOSITIONTYPES_POSITION_ETRG" 
BEFORE INSERT OR UPDATE ON adjpositiontypes
FOR EACH ROW
DECLARE
  v_val adjpositiontypes.position%TYPE;
  v_test adjpositiontypes.position%TYPE;
BEGIN
  v_val := 'a';
  v_test := TRIM(:new.position);
  if v_test = '1' OR v_test = 'a' THEN
  v_val := 'a';
  elsif v_test = '2' OR v_test = 'p' THEN
  v_val := 'p';
  elsif v_test = '3' OR v_test = 'ip' THEN
  v_val := 'ip';
  end if;  :new.position := v_val;
END;
/
ALTER TRIGGER "ADJPOSITIONTYPES_POSITION_ETRG" ENABLE;
