--------------------------------------------------------
--  DDL for Index PRIMARY_6
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_6" ON "MORPHMAPS" ("MORPHID", "POS", "WORDID") ;
