--------------------------------------------------------
--  DDL for Index K_VFRAMEMAPS_WORDID
--------------------------------------------------------

  CREATE INDEX "K_VFRAMEMAPS_WORDID" ON "VFRAMEMAPS" ("WORDID") ;
