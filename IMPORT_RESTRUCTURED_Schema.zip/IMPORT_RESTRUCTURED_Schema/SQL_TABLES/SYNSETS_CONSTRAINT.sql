--------------------------------------------------------
--  Constraints for Table SYNSETS
--------------------------------------------------------

  ALTER TABLE "SYNSETS" MODIFY ("SYNSETID" NOT NULL ENABLE);
  ALTER TABLE "SYNSETS" MODIFY ("LEXDOMAINID" NOT NULL ENABLE);
  ALTER TABLE "SYNSETS" ADD CONSTRAINT "PRIMARY_12" PRIMARY KEY ("SYNSETID") ENABLE;
