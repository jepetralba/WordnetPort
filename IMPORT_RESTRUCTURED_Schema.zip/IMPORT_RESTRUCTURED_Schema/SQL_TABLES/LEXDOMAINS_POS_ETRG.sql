--------------------------------------------------------
--  DDL for Trigger LEXDOMAINS_POS_ETRG
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "LEXDOMAINS_POS_ETRG" 
BEFORE INSERT OR UPDATE ON lexdomains
FOR EACH ROW
DECLARE
  v_val lexdomains.pos%TYPE;
  v_test lexdomains.pos%TYPE;
BEGIN
  v_val := null;
  v_test := TRIM(:new.pos);
  if v_test = '1' OR v_test = 'n' THEN
  v_val := 'n';
  elsif v_test = '2' OR v_test = 'v' THEN
  v_val := 'v';
  elsif v_test = '3' OR v_test = 'a' THEN
  v_val := 'a';
  elsif v_test = '4' OR v_test = 'r' THEN
  v_val := 'r';
  elsif v_test = '5' OR v_test = 's' THEN
  v_val := 's';
  end if;  :new.pos := v_val;
END;
/
ALTER TRIGGER "LEXDOMAINS_POS_ETRG" ENABLE;
