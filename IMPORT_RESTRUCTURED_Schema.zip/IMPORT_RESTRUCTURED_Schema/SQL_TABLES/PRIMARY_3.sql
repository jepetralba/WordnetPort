--------------------------------------------------------
--  DDL for Index PRIMARY_3
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_3" ON "LEXDOMAINS" ("LEXDOMAINID") ;
