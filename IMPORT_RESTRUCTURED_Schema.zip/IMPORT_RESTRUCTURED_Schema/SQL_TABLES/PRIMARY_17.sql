--------------------------------------------------------
--  DDL for Index PRIMARY_17
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_17" ON "ADJPOSITIONTYPES" ("POSITION") ;
