--------------------------------------------------------
--  DDL for Index PRIMARY_2
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_2" ON "CASEDWORDS" ("CASEDWORDID") ;
