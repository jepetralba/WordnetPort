--------------------------------------------------------
--  DDL for Index PRIMARY_13
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_13" ON "VFRAMEMAPS" ("SYNSETID", "WORDID", "FRAMEID") ;
