--------------------------------------------------------
--  DDL for Table VFRAMESENTENCES
--------------------------------------------------------

  CREATE TABLE "VFRAMESENTENCES" ("SENTENCEID" NUMBER(5,0) DEFAULT '0', "SENTENCE" VARCHAR2(4000)) ;
