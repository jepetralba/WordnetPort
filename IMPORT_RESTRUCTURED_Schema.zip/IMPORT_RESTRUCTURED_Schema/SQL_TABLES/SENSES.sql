--------------------------------------------------------
--  DDL for Table SENSES
--------------------------------------------------------

  CREATE TABLE "SENSES" ("WORDID" NUMBER(12,0) DEFAULT '0', "CASEDWORDID" NUMBER(12,0), "SYNSETID" NUMBER(10,0) DEFAULT '0', "SENSEID" NUMBER(12,0), "SENSENUM" NUMBER(3,0) DEFAULT '0', "LEXID" NUMBER(3,0) DEFAULT '0', "TAGCOUNT" NUMBER(12,0), "SENSEKEY" VARCHAR2(100 CHAR)) ;
