--------------------------------------------------------
--  DDL for Index PRIMARY_11
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_11" ON "SENSES" ("WORDID", "SYNSETID") ;
