--------------------------------------------------------
--  DDL for Index K_LEXLINKS_LINKID
--------------------------------------------------------

  CREATE INDEX "K_LEXLINKS_LINKID" ON "LEXLINKS" ("LINKID") ;
