--------------------------------------------------------
--  Constraints for Table MORPHMAPS
--------------------------------------------------------

  ALTER TABLE "MORPHMAPS" MODIFY ("WORDID" NOT NULL ENABLE);
  ALTER TABLE "MORPHMAPS" MODIFY ("POS" NOT NULL ENABLE);
  ALTER TABLE "MORPHMAPS" MODIFY ("MORPHID" NOT NULL ENABLE);
  ALTER TABLE "MORPHMAPS" ADD CONSTRAINT "PRIMARY_6" PRIMARY KEY ("MORPHID", "POS", "WORDID") ENABLE;
