--------------------------------------------------------
--  DDL for Index K_VFRAMESENTENCEMAPS_WORDID
--------------------------------------------------------

  CREATE INDEX "K_VFRAMESENTENCEMAPS_WORDID" ON "VFRAMESENTENCEMAPS" ("WORDID") ;
