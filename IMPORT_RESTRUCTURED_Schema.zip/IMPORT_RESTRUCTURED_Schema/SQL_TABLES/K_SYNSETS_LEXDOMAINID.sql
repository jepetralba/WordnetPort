--------------------------------------------------------
--  DDL for Index K_SYNSETS_LEXDOMAINID
--------------------------------------------------------

  CREATE INDEX "K_SYNSETS_LEXDOMAINID" ON "SYNSETS" ("LEXDOMAINID") ;
