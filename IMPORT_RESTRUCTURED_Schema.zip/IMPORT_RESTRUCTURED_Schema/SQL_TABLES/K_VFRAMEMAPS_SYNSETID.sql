--------------------------------------------------------
--  DDL for Index K_VFRAMEMAPS_SYNSETID
--------------------------------------------------------

  CREATE INDEX "K_VFRAMEMAPS_SYNSETID" ON "VFRAMEMAPS" ("SYNSETID") ;
