--------------------------------------------------------
--  DDL for Table VFRAMESENTENCEMAPS
--------------------------------------------------------

  CREATE TABLE "VFRAMESENTENCEMAPS" ("SYNSETID" NUMBER(10,0) DEFAULT '0', "WORDID" NUMBER(12,0) DEFAULT '0', "SENTENCEID" NUMBER(5,0) DEFAULT '0') ;
