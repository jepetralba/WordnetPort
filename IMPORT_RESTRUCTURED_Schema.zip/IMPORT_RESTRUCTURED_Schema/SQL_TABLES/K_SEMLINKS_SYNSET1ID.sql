--------------------------------------------------------
--  DDL for Index K_SEMLINKS_SYNSET1ID
--------------------------------------------------------

  CREATE INDEX "K_SEMLINKS_SYNSET1ID" ON "SEMLINKS" ("SYNSET1ID") ;
