--------------------------------------------------------
--  DDL for Table LINKTYPES
--------------------------------------------------------

  CREATE TABLE "LINKTYPES" ("LINKID" NUMBER(3,0) DEFAULT '0', "LINK" VARCHAR2(50 CHAR), "RECURSES" NUMBER(3,0) DEFAULT '0') ;
