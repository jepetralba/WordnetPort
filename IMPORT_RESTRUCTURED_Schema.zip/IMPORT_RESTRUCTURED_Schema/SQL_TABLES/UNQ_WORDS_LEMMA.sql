--------------------------------------------------------
--  DDL for Index UNQ_WORDS_LEMMA
--------------------------------------------------------

  CREATE UNIQUE INDEX "UNQ_WORDS_LEMMA" ON "WORDS" ("LEMMA") ;
