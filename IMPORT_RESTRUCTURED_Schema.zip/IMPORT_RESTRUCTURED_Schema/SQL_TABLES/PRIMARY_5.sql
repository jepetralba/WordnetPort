--------------------------------------------------------
--  DDL for Index PRIMARY_5
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_5" ON "LINKTYPES" ("LINKID") ;
