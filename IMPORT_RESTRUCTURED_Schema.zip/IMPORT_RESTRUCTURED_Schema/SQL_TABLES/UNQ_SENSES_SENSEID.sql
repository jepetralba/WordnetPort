--------------------------------------------------------
--  DDL for Index UNQ_SENSES_SENSEID
--------------------------------------------------------

  CREATE UNIQUE INDEX "UNQ_SENSES_SENSEID" ON "SENSES" ("SENSEID") ;
