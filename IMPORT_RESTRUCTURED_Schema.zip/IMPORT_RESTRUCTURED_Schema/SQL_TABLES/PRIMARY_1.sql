--------------------------------------------------------
--  DDL for Index PRIMARY_1
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_1" ON "WORDS" ("WORDID") ;
