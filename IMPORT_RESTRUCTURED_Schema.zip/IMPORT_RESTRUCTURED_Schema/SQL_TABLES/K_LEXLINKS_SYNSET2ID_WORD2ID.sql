--------------------------------------------------------
--  DDL for Index K_LEXLINKS_SYNSET2ID_WORD2ID
--------------------------------------------------------

  CREATE INDEX "K_LEXLINKS_SYNSET2ID_WORD2ID" ON "LEXLINKS" ("SYNSET2ID", "WORD2ID") ;
