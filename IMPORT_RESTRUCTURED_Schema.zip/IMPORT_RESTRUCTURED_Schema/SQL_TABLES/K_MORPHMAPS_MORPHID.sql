--------------------------------------------------------
--  DDL for Index K_MORPHMAPS_MORPHID
--------------------------------------------------------

  CREATE INDEX "K_MORPHMAPS_MORPHID" ON "MORPHMAPS" ("MORPHID") ;
