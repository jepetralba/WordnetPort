--------------------------------------------------------
--  DDL for Index K_LEXLINKS_SYNSET1ID_WORD1ID
--------------------------------------------------------

  CREATE INDEX "K_LEXLINKS_SYNSET1ID_WORD1ID" ON "LEXLINKS" ("SYNSET1ID", "WORD1ID") ;
