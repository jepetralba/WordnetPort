--------------------------------------------------------
--  DDL for Index K_LEXLINKS_SYNSET1ID
--------------------------------------------------------

  CREATE INDEX "K_LEXLINKS_SYNSET1ID" ON "LEXLINKS" ("SYNSET1ID") ;
