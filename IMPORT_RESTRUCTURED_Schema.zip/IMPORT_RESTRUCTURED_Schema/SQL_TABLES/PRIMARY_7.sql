--------------------------------------------------------
--  DDL for Index PRIMARY_7
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_7" ON "MORPHS" ("MORPHID") ;
