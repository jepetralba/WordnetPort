--------------------------------------------------------
--  Ref Constraints for Table SYNSETS
--------------------------------------------------------

  ALTER TABLE "SYNSETS" ADD CONSTRAINT "FK_SYNSETS_LEXDOMAINID" FOREIGN KEY ("LEXDOMAINID") REFERENCES "LEXDOMAINS" ("LEXDOMAINID") ENABLE;
