--------------------------------------------------------
--  Ref Constraints for Table SENSES
--------------------------------------------------------

  ALTER TABLE "SENSES" ADD CONSTRAINT "FK_SENSES_SYNSETID" FOREIGN KEY ("SYNSETID") REFERENCES "SYNSETS" ("SYNSETID") ENABLE;
  ALTER TABLE "SENSES" ADD CONSTRAINT "FK_SENSES_WORDID" FOREIGN KEY ("WORDID") REFERENCES "WORDS" ("WORDID") ENABLE;
