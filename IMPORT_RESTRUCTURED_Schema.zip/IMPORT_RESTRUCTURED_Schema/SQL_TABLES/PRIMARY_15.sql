--------------------------------------------------------
--  DDL for Index PRIMARY_15
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_15" ON "VFRAMESENTENCEMAPS" ("SYNSETID", "WORDID", "SENTENCEID") ;
