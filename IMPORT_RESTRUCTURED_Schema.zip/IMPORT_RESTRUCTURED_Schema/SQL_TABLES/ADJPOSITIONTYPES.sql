--------------------------------------------------------
--  DDL for Table ADJPOSITIONTYPES
--------------------------------------------------------

  CREATE TABLE "ADJPOSITIONTYPES" ("POSITION" VARCHAR2(4000 CHAR), "POSITIONNAME" VARCHAR2(24 CHAR)) ;
