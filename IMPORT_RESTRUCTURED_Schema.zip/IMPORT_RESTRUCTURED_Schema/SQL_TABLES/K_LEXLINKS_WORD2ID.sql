--------------------------------------------------------
--  DDL for Index K_LEXLINKS_WORD2ID
--------------------------------------------------------

  CREATE INDEX "K_LEXLINKS_WORD2ID" ON "LEXLINKS" ("WORD2ID") ;
