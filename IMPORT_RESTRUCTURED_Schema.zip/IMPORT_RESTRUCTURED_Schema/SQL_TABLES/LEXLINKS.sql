--------------------------------------------------------
--  DDL for Table LEXLINKS
--------------------------------------------------------

  CREATE TABLE "LEXLINKS" ("SYNSET1ID" NUMBER(10,0) DEFAULT '0', "WORD1ID" NUMBER(12,0) DEFAULT '0', "SYNSET2ID" NUMBER(10,0) DEFAULT '0', "WORD2ID" NUMBER(12,0) DEFAULT '0', "LINKID" NUMBER(3,0) DEFAULT '0') ;
