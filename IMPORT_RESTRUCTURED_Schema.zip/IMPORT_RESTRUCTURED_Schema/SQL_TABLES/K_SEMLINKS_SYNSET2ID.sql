--------------------------------------------------------
--  DDL for Index K_SEMLINKS_SYNSET2ID
--------------------------------------------------------

  CREATE INDEX "K_SEMLINKS_SYNSET2ID" ON "SEMLINKS" ("SYNSET2ID") ;
