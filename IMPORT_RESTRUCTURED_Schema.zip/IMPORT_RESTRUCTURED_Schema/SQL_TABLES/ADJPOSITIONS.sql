--------------------------------------------------------
--  DDL for Table ADJPOSITIONS
--------------------------------------------------------

  CREATE TABLE "ADJPOSITIONS" ("SYNSETID" NUMBER(10,0) DEFAULT '0', "WORDID" NUMBER(12,0) DEFAULT '0', "POSITION" VARCHAR2(4000 CHAR) DEFAULT 'a') ;
