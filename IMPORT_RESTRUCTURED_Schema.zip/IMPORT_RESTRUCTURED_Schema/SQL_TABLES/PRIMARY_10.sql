--------------------------------------------------------
--  DDL for Index PRIMARY_10
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_10" ON "SEMLINKS" ("SYNSET1ID", "SYNSET2ID", "LINKID") ;
