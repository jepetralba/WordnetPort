--------------------------------------------------------
--  DDL for Table CASEDWORDS
--------------------------------------------------------

  CREATE TABLE "CASEDWORDS" ("CASEDWORDID" NUMBER(12,0) DEFAULT '0', "WORDID" NUMBER(12,0) DEFAULT '0', "CASED" VARCHAR2(80 CHAR)) ;
