REM INSERTING into POSTYPES
SET DEFINE OFF;
Insert into POSTYPES (POS,POSNAME) values ('n','noun');
Insert into POSTYPES (POS,POSNAME) values ('v','verb');
Insert into POSTYPES (POS,POSNAME) values ('a','adjective');
Insert into POSTYPES (POS,POSNAME) values ('r','adverb');
Insert into POSTYPES (POS,POSNAME) values ('s','adjective satellite');
