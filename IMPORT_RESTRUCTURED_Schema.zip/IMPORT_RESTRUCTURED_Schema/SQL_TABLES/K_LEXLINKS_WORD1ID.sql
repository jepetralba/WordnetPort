--------------------------------------------------------
--  DDL for Index K_LEXLINKS_WORD1ID
--------------------------------------------------------

  CREATE INDEX "K_LEXLINKS_WORD1ID" ON "LEXLINKS" ("WORD1ID") ;
