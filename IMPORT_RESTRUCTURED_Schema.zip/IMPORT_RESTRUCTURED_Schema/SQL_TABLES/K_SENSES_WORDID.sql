--------------------------------------------------------
--  DDL for Index K_SENSES_WORDID
--------------------------------------------------------

  CREATE INDEX "K_SENSES_WORDID" ON "SENSES" ("WORDID") ;
