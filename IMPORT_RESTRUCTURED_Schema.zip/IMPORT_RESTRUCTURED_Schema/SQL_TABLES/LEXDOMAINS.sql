--------------------------------------------------------
--  DDL for Table LEXDOMAINS
--------------------------------------------------------

  CREATE TABLE "LEXDOMAINS" ("LEXDOMAINID" NUMBER(3,0) DEFAULT '0', "LEXDOMAINNAME" VARCHAR2(32 CHAR), "POS" VARCHAR2(4000 CHAR)) ;
