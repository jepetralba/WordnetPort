--------------------------------------------------------
--  DDL for Table SAMPLES
--------------------------------------------------------

  CREATE TABLE "SAMPLES" ("SYNSETID" NUMBER(10,0) DEFAULT NULL, "SAMPLEID" NUMBER(3,0) DEFAULT '0', "SAMPLE" VARCHAR2(4000)) ;
