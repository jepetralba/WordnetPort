--------------------------------------------------------
--  Constraints for Table VFRAMES
--------------------------------------------------------

  ALTER TABLE "VFRAMES" MODIFY ("FRAMEID" NOT NULL ENABLE);
  ALTER TABLE "VFRAMES" ADD CONSTRAINT "PRIMARY_14" PRIMARY KEY ("FRAMEID") ENABLE;
