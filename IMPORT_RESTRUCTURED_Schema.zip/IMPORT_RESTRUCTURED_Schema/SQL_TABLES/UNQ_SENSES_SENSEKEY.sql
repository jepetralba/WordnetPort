--------------------------------------------------------
--  DDL for Index UNQ_SENSES_SENSEKEY
--------------------------------------------------------

  CREATE UNIQUE INDEX "UNQ_SENSES_SENSEKEY" ON "SENSES" ("SENSEKEY") ;
