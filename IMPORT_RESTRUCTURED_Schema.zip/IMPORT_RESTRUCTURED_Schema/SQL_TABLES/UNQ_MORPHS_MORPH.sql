--------------------------------------------------------
--  DDL for Index UNQ_MORPHS_MORPH
--------------------------------------------------------

  CREATE UNIQUE INDEX "UNQ_MORPHS_MORPH" ON "MORPHS" ("MORPH") ;
