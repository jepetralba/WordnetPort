--------------------------------------------------------
--  DDL for Index K_VFRAMEMAPS_FRAMEID
--------------------------------------------------------

  CREATE INDEX "K_VFRAMEMAPS_FRAMEID" ON "VFRAMEMAPS" ("FRAMEID") ;
