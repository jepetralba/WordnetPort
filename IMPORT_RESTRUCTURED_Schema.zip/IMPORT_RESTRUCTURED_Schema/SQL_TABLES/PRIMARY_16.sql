--------------------------------------------------------
--  DDL for Index PRIMARY_16
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_16" ON "VFRAMESENTENCES" ("SENTENCEID") ;
