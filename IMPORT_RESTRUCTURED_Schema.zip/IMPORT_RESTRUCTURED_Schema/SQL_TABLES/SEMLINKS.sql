--------------------------------------------------------
--  DDL for Table SEMLINKS
--------------------------------------------------------

  CREATE TABLE "SEMLINKS" ("SYNSET1ID" NUMBER(10,0) DEFAULT '0', "SYNSET2ID" NUMBER(10,0) DEFAULT '0', "LINKID" NUMBER(3,0) DEFAULT '0') ;
