--------------------------------------------------------
--  DDL for Index PRIMARY_9
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_9" ON "SAMPLES" ("SYNSETID", "SAMPLEID") ;
