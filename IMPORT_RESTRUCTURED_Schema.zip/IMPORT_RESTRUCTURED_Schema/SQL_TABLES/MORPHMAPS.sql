--------------------------------------------------------
--  DDL for Table MORPHMAPS
--------------------------------------------------------

  CREATE TABLE "MORPHMAPS" ("WORDID" NUMBER(12,0) DEFAULT '0', "POS" VARCHAR2(4000 CHAR) DEFAULT 'n', "MORPHID" NUMBER(12,0) DEFAULT '0') ;
