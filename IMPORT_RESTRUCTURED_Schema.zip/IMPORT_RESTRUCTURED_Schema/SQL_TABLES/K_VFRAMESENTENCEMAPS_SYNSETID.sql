--------------------------------------------------------
--  DDL for Index K_VFRAMESENTENCEMAPS_SYNSETID
--------------------------------------------------------

  CREATE INDEX "K_VFRAMESENTENCEMAPS_SYNSETID" ON "VFRAMESENTENCEMAPS" ("SYNSETID") ;
