--------------------------------------------------------
--  Ref Constraints for Table CASEDWORDS
--------------------------------------------------------

  ALTER TABLE "CASEDWORDS" ADD CONSTRAINT "FK_CASEDWORDS_WORDID" FOREIGN KEY ("WORDID") REFERENCES "WORDS" ("WORDID") ENABLE;
