--------------------------------------------------------
--  DDL for Index K_SEMLINKS_LINKID
--------------------------------------------------------

  CREATE INDEX "K_SEMLINKS_LINKID" ON "SEMLINKS" ("LINKID") ;
