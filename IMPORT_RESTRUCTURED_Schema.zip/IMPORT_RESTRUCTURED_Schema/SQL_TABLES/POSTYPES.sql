--------------------------------------------------------
--  DDL for Table POSTYPES
--------------------------------------------------------

  CREATE TABLE "POSTYPES" ("POS" VARCHAR2(4000 CHAR), "POSNAME" VARCHAR2(20 CHAR)) ;
