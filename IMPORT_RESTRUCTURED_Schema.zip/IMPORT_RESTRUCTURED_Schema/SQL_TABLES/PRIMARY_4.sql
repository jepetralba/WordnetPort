--------------------------------------------------------
--  DDL for Index PRIMARY_4
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_4" ON "LEXLINKS" ("WORD1ID", "SYNSET1ID", "WORD2ID", "SYNSET2ID", "LINKID") ;
