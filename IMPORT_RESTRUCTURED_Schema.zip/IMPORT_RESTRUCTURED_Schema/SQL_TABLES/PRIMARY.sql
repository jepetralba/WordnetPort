--------------------------------------------------------
--  DDL for Index PRIMARY
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY" ON "ADJPOSITIONS" ("SYNSETID", "WORDID") ;
