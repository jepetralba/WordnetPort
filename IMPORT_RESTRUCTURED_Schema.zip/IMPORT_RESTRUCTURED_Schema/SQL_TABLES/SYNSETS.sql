--------------------------------------------------------
--  DDL for Table SYNSETS
--------------------------------------------------------

  CREATE TABLE "SYNSETS" ("SYNSETID" NUMBER(10,0) DEFAULT '0', "POS" CHAR, "LEXDOMAINID" NUMBER(3,0) DEFAULT '0', "DEFINITION" VARCHAR2(4000)) ;
