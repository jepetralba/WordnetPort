--------------------------------------------------------
--  DDL for Index K_ADJPOSITIONS_WORDID
--------------------------------------------------------

  CREATE INDEX "K_ADJPOSITIONS_WORDID" ON "ADJPOSITIONS" ("WORDID") ;
