--------------------------------------------------------
--  DDL for Index K_VFRAMESENTENCEMAPS_SENTENCEI
--------------------------------------------------------

  CREATE INDEX "K_VFRAMESENTENCEMAPS_SENTENCEI" ON "VFRAMESENTENCEMAPS" ("SENTENCEID") ;
