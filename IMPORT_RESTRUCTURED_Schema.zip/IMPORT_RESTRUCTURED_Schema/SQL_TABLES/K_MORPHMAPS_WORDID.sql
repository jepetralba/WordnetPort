--------------------------------------------------------
--  DDL for Index K_MORPHMAPS_WORDID
--------------------------------------------------------

  CREATE INDEX "K_MORPHMAPS_WORDID" ON "MORPHMAPS" ("WORDID") ;
