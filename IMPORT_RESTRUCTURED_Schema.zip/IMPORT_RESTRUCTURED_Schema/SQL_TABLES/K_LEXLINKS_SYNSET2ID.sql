--------------------------------------------------------
--  DDL for Index K_LEXLINKS_SYNSET2ID
--------------------------------------------------------

  CREATE INDEX "K_LEXLINKS_SYNSET2ID" ON "LEXLINKS" ("SYNSET2ID") ;
