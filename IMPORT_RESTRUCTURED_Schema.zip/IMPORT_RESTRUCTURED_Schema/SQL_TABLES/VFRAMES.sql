--------------------------------------------------------
--  DDL for Table VFRAMES
--------------------------------------------------------

  CREATE TABLE "VFRAMES" ("FRAMEID" NUMBER(3,0) DEFAULT '0', "FRAME" VARCHAR2(50 CHAR)) ;
