--------------------------------------------------------
--  DDL for Index PRIMARY_8
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRIMARY_8" ON "POSTYPES" ("POS") ;
