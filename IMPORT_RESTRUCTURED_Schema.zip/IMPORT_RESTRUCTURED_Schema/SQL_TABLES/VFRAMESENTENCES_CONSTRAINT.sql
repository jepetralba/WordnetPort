--------------------------------------------------------
--  Constraints for Table VFRAMESENTENCES
--------------------------------------------------------

  ALTER TABLE "VFRAMESENTENCES" MODIFY ("SENTENCEID" NOT NULL ENABLE);
  ALTER TABLE "VFRAMESENTENCES" ADD CONSTRAINT "PRIMARY_16" PRIMARY KEY ("SENTENCEID") ENABLE;
