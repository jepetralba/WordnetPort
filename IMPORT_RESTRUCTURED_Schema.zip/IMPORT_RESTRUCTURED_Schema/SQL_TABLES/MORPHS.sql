--------------------------------------------------------
--  DDL for Table MORPHS
--------------------------------------------------------

  CREATE TABLE "MORPHS" ("MORPHID" NUMBER(12,0) DEFAULT '0', "MORPH" VARCHAR2(70 CHAR)) ;
