--------------------------------------------------------
--  Constraints for Table LINKTYPES
--------------------------------------------------------

  ALTER TABLE "LINKTYPES" MODIFY ("LINKID" NOT NULL ENABLE);
  ALTER TABLE "LINKTYPES" MODIFY ("RECURSES" NOT NULL ENABLE);
  ALTER TABLE "LINKTYPES" ADD CONSTRAINT "PRIMARY_5" PRIMARY KEY ("LINKID") ENABLE;
