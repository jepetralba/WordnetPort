--------------------------------------------------------
--  Ref Constraints for Table MORPHMAPS
--------------------------------------------------------

  ALTER TABLE "MORPHMAPS" ADD CONSTRAINT "FK_MORPHMAPS_MORPHID" FOREIGN KEY ("MORPHID") REFERENCES "MORPHS" ("MORPHID") ENABLE;
  ALTER TABLE "MORPHMAPS" ADD CONSTRAINT "FK_MORPHMAPS_WORDID" FOREIGN KEY ("WORDID") REFERENCES "WORDS" ("WORDID") ENABLE;
