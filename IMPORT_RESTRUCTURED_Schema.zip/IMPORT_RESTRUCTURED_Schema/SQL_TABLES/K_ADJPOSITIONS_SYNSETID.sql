--------------------------------------------------------
--  DDL for Index K_ADJPOSITIONS_SYNSETID
--------------------------------------------------------

  CREATE INDEX "K_ADJPOSITIONS_SYNSETID" ON "ADJPOSITIONS" ("SYNSETID") ;
