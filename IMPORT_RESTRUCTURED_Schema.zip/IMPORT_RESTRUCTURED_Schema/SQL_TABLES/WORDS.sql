--------------------------------------------------------
--  DDL for Table WORDS
--------------------------------------------------------

  CREATE TABLE "WORDS" ("WORDID" NUMBER(12,0) DEFAULT '0', "LEMMA" VARCHAR2(80 CHAR)) ;
