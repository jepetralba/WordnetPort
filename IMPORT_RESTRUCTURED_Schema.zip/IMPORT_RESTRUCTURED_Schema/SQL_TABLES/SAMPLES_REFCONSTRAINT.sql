--------------------------------------------------------
--  Ref Constraints for Table SAMPLES
--------------------------------------------------------

  ALTER TABLE "SAMPLES" ADD CONSTRAINT "FK_SAMPLES_SYNSETID" FOREIGN KEY ("SYNSETID") REFERENCES "SYNSETS" ("SYNSETID") ENABLE;
