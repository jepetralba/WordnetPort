--------------------------------------------------------
--  Constraints for Table SAMPLES
--------------------------------------------------------

  ALTER TABLE "SAMPLES" MODIFY ("SYNSETID" NOT NULL ENABLE);
  ALTER TABLE "SAMPLES" MODIFY ("SAMPLEID" NOT NULL ENABLE);
  ALTER TABLE "SAMPLES" MODIFY ("SAMPLE" NOT NULL ENABLE);
  ALTER TABLE "SAMPLES" ADD CONSTRAINT "PRIMARY_9" PRIMARY KEY ("SYNSETID", "SAMPLEID") ENABLE;
