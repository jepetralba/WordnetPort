--------------------------------------------------------
--  Constraints for Table POSTYPES
--------------------------------------------------------

  ALTER TABLE "POSTYPES" MODIFY ("POS" NOT NULL ENABLE);
  ALTER TABLE "POSTYPES" ADD CONSTRAINT "PRIMARY_8" PRIMARY KEY ("POS") ENABLE;
  ALTER TABLE "POSTYPES" MODIFY ("POSNAME" NOT NULL ENABLE);
