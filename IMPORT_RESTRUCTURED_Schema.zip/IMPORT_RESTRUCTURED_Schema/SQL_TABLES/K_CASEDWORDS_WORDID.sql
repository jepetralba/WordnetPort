--------------------------------------------------------
--  DDL for Index K_CASEDWORDS_WORDID
--------------------------------------------------------

  CREATE INDEX "K_CASEDWORDS_WORDID" ON "CASEDWORDS" ("WORDID") ;
