--------------------------------------------------------
--  Constraints for Table LEXDOMAINS
--------------------------------------------------------

  ALTER TABLE "LEXDOMAINS" MODIFY ("LEXDOMAINID" NOT NULL ENABLE);
  ALTER TABLE "LEXDOMAINS" ADD CONSTRAINT "PRIMARY_3" PRIMARY KEY ("LEXDOMAINID") ENABLE;
