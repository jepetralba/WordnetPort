--------------------------------------------------------
--  DDL for Index K_SAMPLES_SYNSETID
--------------------------------------------------------

  CREATE INDEX "K_SAMPLES_SYNSETID" ON "SAMPLES" ("SYNSETID") ;
