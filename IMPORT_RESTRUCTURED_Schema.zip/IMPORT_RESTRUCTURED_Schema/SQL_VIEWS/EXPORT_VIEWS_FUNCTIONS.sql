--------------------------------------------------------
--  File created - Friday-July-18-2014   
--------------------------------------------------------

create or replace FUNCTION "GET_SAMPLES" (p_synsetid  in  number)
  RETURN VARCHAR2
IS
  l_text  VARCHAR2(32767) := NULL;
BEGIN
  FOR cur_rec IN (SELECT sample FROM samples WHERE synsetid = p_synsetid) LOOP
    l_text := l_text || '|' || cur_rec.sample;
  END LOOP;
  RETURN LTRIM(l_text, '|');
END;
/


--------------------------------------------------------
--  DDL for View SAMPLESETS
--------------------------------------------------------

CREATE OR REPLACE VIEW "SAMPLESETS" ("SYNSETID", "sampleset") AS SELECT synsetid,
       get_samples(synsetid) AS sample
FROM   samples
GROUP by synsetid;

--------------------------------------------------------
--  DDL for View ADJECTIVESWITHPOSITIONS
--------------------------------------------------------

 CREATE OR REPLACE VIEW "ADJECTIVESWITHPOSITIONS" ("SYNSETID", "WORDID", "CASEDWORDID", "SENSEID", "SENSENUM", "LEXID", "TAGCOUNT", "SENSEKEY", "POSITION", "LEMMA", "POS", "LEXDOMAINID", "DEFINITION") AS select senses.synsetid AS
synsetid,senses.wordid AS
wordid,senses.casedwordid AS
casedwordid,senses.senseid AS
senseid,senses.sensenum AS
sensenum,senses.lexid AS
lexid,senses.tagcount AS
tagcount,senses.sensekey AS
sensekey,adjpositions.position AS
position,words.lemma AS
lemma,synsets.pos AS
pos,synsets.lexdomainid AS
lexdomainid,synsets.definition AS definition from
(((senses join adjpositions
on(((senses.wordid =
adjpositions.wordid) and
(senses.synsetid =
adjpositions.synsetid)))) left join
words on((senses.wordid =
words.wordid))) left join
synsets on((senses.synsetid =
synsets.synsetid)));

--------------------------------------------------------
--  DDL for View MORPHOLOGY
--------------------------------------------------------

CREATE OR REPLACE VIEW "MORPHOLOGY" ("MORPHID", "WORDID", "LEMMA", "POS", "MORPH") AS select morphmaps.morphid AS
morphid,words.wordid AS
wordid,words.lemma AS
lemma,morphmaps.pos AS
pos,morphs.morph AS morph from
((words join morphmaps
on((words.wordid =
morphmaps.wordid))) join morphs
on((morphmaps.morphid =
morphs.morphid)));

--------------------------------------------------------
--  DDL for View SENSESXSYNSETS
--------------------------------------------------------

  CREATE OR REPLACE VIEW "SENSESXSYNSETS" ("SYNSETID", "WORDID", "CASEDWORDID", "SENSEID", "SENSENUM", "LEXID", "TAGCOUNT", "SENSEKEY", "POS", "LEXDOMAINID", "DEFINITION") AS select senses.synsetid AS
synsetid,senses.wordid AS
wordid,senses.casedwordid AS
casedwordid,senses.senseid AS
senseid,senses.sensenum AS
sensenum,senses.lexid AS
lexid,senses.tagcount AS
tagcount,senses.sensekey AS
sensekey,synsets.pos AS
pos,synsets.lexdomainid AS
lexdomainid,synsets.definition AS definition from
(senses join synsets
on((senses.synsetid =
synsets.synsetid)));
--------------------------------------------------------
--  DDL for View SENSESXLEXLINKSXSENSES
--------------------------------------------------------

  CREATE OR REPLACE VIEW "SENSESXLEXLINKSXSENSES" ("LINKID", "SSYNSETID", "SWORDID", "SSENSEID", "SCASEDWORDID", "SSENSENUM", "SLEXID", "STAGCOUNT", "SSENSEKEY", "SPOS", "SLEXDOMAINID", "SDEFINITION", "DSYNSETID", "DWORDID", "DSENSEID", "DCASEDWORDID", "DSENSENUM", "DLEXID", "DTAGCOUNT", "DSENSEKEY", "DPOS", "DLEXDOMAINID", "DDEFINITION") AS select l.linkid AS linkid,s.synsetid AS
ssynsetid,s.wordid AS swordid,s.senseid AS
ssenseid,s.casedwordid AS scasedwordid,s.sensenum AS
ssensenum,s.lexid AS slexid,s.tagcount AS stagcount,s.sensekey
AS ssensekey,s.pos AS spos,s.lexdomainid AS
slexdomainid,s.definition AS sdefinition,d.synsetid AS
dsynsetid,d.wordid AS dwordid,d.senseid AS
dsenseid,d.casedwordid AS dcasedwordid,d.sensenum AS
dsensenum,d.lexid AS dlexid,d.tagcount AS dtagcount,d.sensekey
AS dsensekey,d.pos AS dpos,d.lexdomainid AS
dlexdomainid,d.definition AS ddefinition from
((sensesxsynsets s join lexlinks
l on(((s.synsetid = l.synset1id) and (s.wordid = l.word1id))))
join sensesxsynsets d on(((l.synset2id =
d.synsetid) and (l.word2id = d.wordid))));
--------------------------------------------------------
--  DDL for View SENSESXSEMLINKSXSENSES
--------------------------------------------------------

  CREATE OR REPLACE VIEW "SENSESXSEMLINKSXSENSES" ("LINKID", "SSYNSETID", "SWORDID", "SSENSEID", "SCASEDWORDID", "SSENSENUM", "SLEXID", "STAGCOUNT", "SSENSEKEY", "SPOS", "SLEXDOMAINID", "SDEFINITION", "DSYNSETID", "DWORDID", "DSENSEID", "DCASEDWORDID", "DSENSENUM", "DLEXID", "DTAGCOUNT", "DSENSEKEY", "DPOS", "DLEXDOMAINID", "DDEFINITION") AS select l.linkid AS linkid,s.synsetid AS ssynsetid,s.wordid AS
swordid,s.senseid AS ssenseid,s.casedwordid AS
scasedwordid,s.sensenum AS ssensenum,s.lexid AS
slexid,s.tagcount AS stagcount,s.sensekey AS ssensekey,s.pos
AS spos,s.lexdomainid AS slexdomainid,s.definition AS
sdefinition,d.synsetid AS dsynsetid,d.wordid AS
dwordid,d.senseid AS dsenseid,d.casedwordid AS
dcasedwordid,d.sensenum AS dsensenum,d.lexid AS
dlexid,d.tagcount AS dtagcount,d.sensekey AS dsensekey,d.pos
AS dpos,d.lexdomainid AS dlexdomainid,d.definition AS ddefinition
from ((sensesxsynsets s join
semlinks l on((s.synsetid = l.synset1id))) join
sensesxsynsets d on((l.synset2id =
d.synsetid)));

--------------------------------------------------------
--  DDL for View SYNSETSXSEMLINKSXSYNSETS
--------------------------------------------------------

  CREATE OR REPLACE VIEW "SYNSETSXSEMLINKSXSYNSETS" ("LINKID", "SSYNSETID", "SDEFINITION", "DSYNSETID", "DDEFINITION") AS select l.linkid AS linkid,s.synsetid AS
ssynsetid,s.definition AS sdefinition,d.synsetid AS
dsynsetid,d.definition AS ddefinition from
((synsets s join semlinks l
on((s.synsetid = l.synset1id))) join synsets d
on((l.synset2id = d.synsetid)));
--------------------------------------------------------
--  DDL for View VERBSWITHFRAMES
--------------------------------------------------------

  CREATE OR REPLACE VIEW "VERBSWITHFRAMES" ("SYNSETID", "WORDID", "FRAMEID", "CASEDWORDID", "SENSEID", "SENSENUM", "LEXID", "TAGCOUNT", "SENSEKEY", "FRAME", "LEMMA", "POS", "LEXDOMAINID", "DEFINITION") AS Select senses.synsetid AS
synsetid,senses.wordid AS
wordid,vframemaps.frameid AS
frameid,senses.casedwordid AS
casedwordid,senses.senseid AS
senseid,senses.sensenum AS
sensenum,senses.lexid AS
lexid,senses.tagcount AS
tagcount,senses.sensekey AS
sensekey,vframes.frame AS
frame,words.lemma AS
lemma,synsets.pos AS
pos,synsets.lexdomainid AS
lexdomainid,synsets.definition AS definition from
((((senses join vframemaps
on(((senses.wordid =
vframemaps.wordid) and
(senses.synsetid =
vframemaps.synsetid)))) join
vframes on((vframemaps.frameid =
vframes.frameid))) left join
words on((senses.wordid =
words.wordid))) left join
synsets on((senses.synsetid =
synsets.synsetid)));
--------------------------------------------------------
--  DDL for View WORDSXSENSES
--------------------------------------------------------

  CREATE OR REPLACE VIEW "WORDSXSENSES" ("WORDID", "LEMMA", "CASEDWORDID", "SYNSETID", "SENSEID", "SENSENUM", "LEXID", "TAGCOUNT", "SENSEKEY") AS select words.wordid AS
wordid,words.lemma AS
lemma,senses.casedwordid AS
casedwordid,senses.synsetid AS
synsetid,senses.senseid AS
senseid,senses.sensenum AS
sensenum,senses.lexid AS
lexid,senses.tagcount AS
tagcount,senses.sensekey AS sensekey from
(words join senses
on((words.wordid =
senses.wordid)));
--------------------------------------------------------
--  DDL for View WORDSXSENSESXSYNSETS
--------------------------------------------------------

  CREATE OR REPLACE VIEW "WORDSXSENSESXSYNSETS" ("SYNSETID", "WORDID", "LEMMA", "CASEDWORDID", "SENSEID", "SENSENUM", "LEXID", "TAGCOUNT", "SENSEKEY", "POS", "LEXDOMAINID", "DEFINITION") AS select senses.synsetid AS
synsetid,words.wordid AS
wordid,words.lemma AS
lemma,senses.casedwordid AS
casedwordid,senses.senseid AS
senseid,senses.sensenum AS
sensenum,senses.lexid AS
lexid,senses.tagcount AS
tagcount,senses.sensekey AS
sensekey,synsets.pos AS
pos,synsets.lexdomainid AS
lexdomainid,synsets.definition AS definition from
((words join senses
on((words.wordid =
senses.wordid))) join synsets
on((senses.synsetid =
synsets.synsetid)));

--------------------------------------------------------
--  DDL for View DICT
--------------------------------------------------------

CREATE OR REPLACE VIEW "DICT" ("SYNSETID", "WORDID", "CASEDWORDID", "LEMMA", "SENSEID", "SENSENUM", "LEXID", "TAGCOUNT", "SENSEKEY", "CASED", "POS", "LEXDOMAINID", "DEFINITION", "SAMPLESET") AS select s.synsetid AS synsetid,words.wordid AS
wordid,s.casedwordid AS casedwordid,words.lemma
AS lemma,s.senseid AS senseid,s.sensenum AS sensenum,s.lexid
AS lexid,s.tagcount AS tagcount,s.sensekey AS
sensekey,casedwords.cased AS
cased,synsets.pos AS
pos,synsets.lexdomainid AS
lexdomainid,synsets.definition AS
definition, samplesets."sampleset" AS sampleset from
((((words left join senses s
on((words.wordid = s.wordid))) left join
casedwords on(((words.wordid =
casedwords.wordid) and (s.casedwordid =
casedwords.casedwordid)))) left join
synsets on((s.synsetid =
synsets.synsetid))) left join
samplesets on((s.synsetid =
samplesets.synsetid)));



create or replace FUNCTION get_words_show_all (p_synsetid  in  number)
  RETURN VARCHAR2
IS
  l_text  VARCHAR2(32767) := NULL;
BEGIN
  FOR cur_rec IN (SELECT CASE WHEN b.cased is null THEN a.lemma ELSE b.cased END || '#' || a.sensenum || '('
|| a.sensekey || ')' lemma
FROM WORDSXSENSESXSYNSETS a left join casedwords b on a.casedwordid=b.casedwordid
WHERE a.synsetid = p_synsetid  order by a.sensenum
) LOOP
    l_text := l_text || ',' || cur_rec.lemma;
  END LOOP;
  RETURN LTRIM(l_text, ',');
END;
/


create or replace FUNCTION get_words (p_synsetid  in  number)
  RETURN VARCHAR2
IS
  l_text  VARCHAR2(32767) := NULL;
BEGIN
  FOR cur_rec IN (SELECT CASE WHEN b.cased is null THEN a.lemma ELSE b.cased END lemma
FROM WORDSXSENSES a left join casedwords b on a.casedwordid=b.casedwordid
WHERE a.synsetid = p_synsetid order by a.sensenum
) LOOP
    l_text := l_text || ',' || cur_rec.lemma;
  END LOOP;
  RETURN LTRIM(l_text, ',');
END;
/

create or replace FUNCTION get_words_show_derivation (p_synsetid  in  number)
  RETURN VARCHAR2
IS
  l_text  VARCHAR2(32767) := NULL;
BEGIN
  FOR cur_rec IN (
SELECT CASE WHEN b.cased is null THEN a.lemma ELSE b.cased END || '#' || a.sensenum || '('
|| a.sensekey || ')'   lemma
FROM WORDSXSENSESXSYNSETS a left join casedwords b on a.casedwordid=b.casedwordid
WHERE a.synsetid = p_synsetid
and a.wordid=
   (select min(wordid) minwordid from WORDSXSENSESXSYNSETS where synsetid = p_synsetid	)
) LOOP
    l_text := l_text || ',' || cur_rec.lemma;
  END LOOP;
  RETURN LTRIM(l_text, ',');
END;
/


CREATE MATERIALIZED VIEW MV_SEARCH_WORDNET AS 
select lemma, synsetid, tagcount, lexdomainname, lexdomainid,  pos, showall, DEFINITION, sampleset, hideall, sensenum from (
SELECT distinct
CASE WHEN a.tagcount <> 0 THEN a.tagcount ELSE null END tagcount,
c.lexdomainname,  c.lexdomainid ,  get_words_show_all(a.synsetid) showall, a.SYNSETID,
  a.WORDID,
  a.SENSEID,
  a.SENSENUM,
  a.POS,
  a.definition,
  a.sampleset,
  get_words(a.synsetid) hideall,
  a.lemma
FROM DICT a join lexdomains c on a.lexdomainid=c.lexdomainid
);



--------------------------------------------------------
--  DDL for Function SF_CNT_IN_SET_RATIO
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "SF_CNT_IN_SET_RATIO" (
  in_string in varchar2,
  set_belong in varchar2) return number
--- select sf_cnt_in_set_ratio( 'abecd', 'aeiouAEIOU ') from dual;
-- return 0.4
-- the higher the ratio the more vowels thus easier words to guess in hangman
 
is
	white_char varchar2(100) := ' -/.''';
	str_len number := 0;
  cnt number := 0;
  in_char char(1);
  in_length number;
  cnt_belong number;
  res number;
begin
  in_length := length(in_string);
  cnt_belong := 0;
  while (cnt < in_length)
  loop
    cnt := cnt + 1;
    in_char := substr(in_string, cnt, 1);
    if instr(white_char, in_char) = 0 then 
       str_len := str_len + 1; 
       if instr(set_belong, in_char) <> 0 then cnt_belong := cnt_belong + 1; end if;
    end if;
  end loop;
  res := cnt_belong/str_len;
  return res;
 end;
/
--------------------------------------------------------
--  DDL for Function SF_CNT_NOT_IN_SET_CONSECUTIVE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "SF_CNT_NOT_IN_SET_CONSECUTIVE" (
  in_string in varchar2,
  set_belong in varchar2) return number
  --- select sf_cnt_not_in_set_consecutive( 'abecdfgha', 'aeiouAEIOU-/.'' ') from dual;
  --- returns 5
is
  max_seq_not_belong number := 0;
  seq_not_belong number := 0;
  in_length number;
  cnt number := 0;
  in_char char(1);
  res number;
begin
  in_length := length(in_string);
  while (cnt < in_length)
  loop
    cnt := cnt + 1;
    in_char := substr(in_string, cnt, 1);
    if instr(set_belong, in_char) = 0 then 
       seq_not_belong := seq_not_belong + 1; 
    else
       if seq_not_belong >= max_seq_not_belong then 
            max_seq_not_belong := seq_not_belong; end if;
      seq_not_belong := 0;
    end if;
  end loop;
  
  if seq_not_belong >= max_seq_not_belong then 
            max_seq_not_belong := seq_not_belong; end if;
   res := max_seq_not_belong;
   return res;
 end;
/
--------------------------------------------------------
--  DDL for Function SF_EXCLUDING_CHARS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "SF_EXCLUDING_CHARS" (
  in_string in varchar2,
  in_excluded_char in varchar2) return number
--- return
-- 0 if string has excluded characters
---1 otherwise
-- select sf_excluding_chars('abcd', '0123456789') from dual;
-- should return 0
 
is
	in_length number;
	str_len number := 0;
  cnt number := 0;
  in_char char(1);
  res integer := 1;
begin
  in_length := length(in_string);
  while (cnt < in_length and res = 1 )
  loop
    cnt := cnt + 1;
    in_char := substr(in_string, cnt, 1);
    if instr(in_excluded_char, in_char) <> 0 then 
       res := 0;
    end if;
  end loop;
 return res;
 end;
/
--------------------------------------------------------
--  DDL for Function SF_STR_LEN
--------------------------------------------------------

create or replace
function sf_str_len (
  in_string in varchar2) return number
-- get the length of string excluding space, - / . '
is
	white_char varchar2(100) := ' -/.''';
	in_length number;
	str_len number := 0;
  cnt number := 0;
  in_char char(1);
  res number;
begin
  in_length := length(in_string);
  while (cnt < in_length)
  loop
    cnt := cnt + 1;
    in_char := substr(in_string, cnt, 1);
    if instr(white_char, in_char) = 0 then 
       str_len := str_len + 1; 
    end if;
  end loop;
  res := str_len;
  return res;
 end;
/


exit;

