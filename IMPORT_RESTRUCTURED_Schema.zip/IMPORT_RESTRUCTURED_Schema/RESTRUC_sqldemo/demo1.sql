---- MV_SEARCH_WORDNET is a table that contains the synsets for a given word

--- Number of rows
select count(*) from MV_SEARCH_WORDNET;
--- 206353

--- row countS of MV_SEARCH_WORDNET per POS
select POS, count(*) ROW_COUNT from MV_SEARCH_WORDNET group by POS;

--- row counts of MV_SEARCH_WORDNET per LEXDOMAINNAME
select POS, LEXDOMAINID, LEXDOMAINNAME, count(*) ROW_COUNT from MV_SEARCH_WORDNET group by POS, LEXDOMAINID, LEXDOMAINNAME;

select * from MV_SEARCH_WORDNET where lemma= 'java' order by INSTR('n,v,a,s,r,' , pos||',') ,sensenum;

select TAGCOUNT, SYNSETID, LEXDOMAINNAME, LEXDOMAINID, POS, SHOWALL, DEFINITION, SAMPLESET from MV_SEARCH_WORDNET where lemma= 'java'
order by INSTR('n,v,a,s,r,' , pos||',') ,sensenum;
--- Show All
--- http://wordnetweb.princeton.edu/perl/webwn?c=3&sub=Change&o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=1&o4=1&i=-1&h=000&s=java

select TAGCOUNT, SYNSETID, LEXDOMAINNAME, LEXDOMAINID, POS, SHOWALL, DEFINITION, SAMPLESET from MV_SEARCH_WORDNET where lemma= 'upstage'
order by INSTR('n,v,a,s,r,' , pos||',') ,sensenum;
--- Show All
---- http://wordnetweb.princeton.edu/perl/webwn?s=upstage&sub=Search+WordNet&o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&h=000

--------------------------------------------------------------------------------------------------------------------------

--- Views that contains a particular relation
---- LINK TABLES

select * from MV_DIRECT_HYPERNYM where a_lemma= 'java' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- hypernym or direct hypernym
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=java&i=7&h=01001010#c

select * from MV_DIRECT_HYPONYM where a_lemma= 'java' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- hyponym or direct hyponym  or troponym (for verb)
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=java&i=2&h=010000#c

select * from MV_INSTANCE_HYPERNYM where a_lemma= 'java' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- instance hypernym or instance
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=java&i=4&h=10000000#c

select * from MV_INSTANCE_HYPONYM where a_lemma= 'apus' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- instance hyponym or instance
---- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=apus&i=1&h=100#c
---- note: MV_INSTANCE_HYPERNYM is a subset of MV_INSTANCE_HYPONYM

select * from MV_PART_HOLONYM where a_lemma= 'java' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- part holonym
---- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=java&i=3&h=10000000#c

select * from MV_PART_MERONYM where a_lemma= 'java' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- part meronym
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=java&i=1&h=10000000#c

select * from MV_MEMBER_HOLONYM where a_lemma= 'angola' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- member holonym
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=angola&i=2&h=1000000#c

select * from MV_MEMBER_MERONYM where a_lemma= 'java' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- member meronym
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=java&i=2&h=10000000#c

select count(*) from MV_MEMBER_MERONYM;

select A_LEXDOMAINNAME, A_POS,  A_DEFINITION, A_SAMPLESET, C_HIDEALL,C_LEXDOMAINNAME, C_POS, C_DEFINITION, C_SAMPLESET  
from MV_MEMBER_MERONYM where a_lemma= 'java' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;

select * from MV_SUBSTANCE_HOLONYM where a_lemma= 'tea' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- substance holonym
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=tea&i=6&h=000010000#c

select * from MV_SUBSTANCE_MERONYM where a_lemma= 'java' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- substance meronym
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=java&i=3&h=010000#c

select * from MV_ENTAILMENT where a_lemma= 'master' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- entail
---- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=master&i=23&h=000000000010100000010000000#c

select * from MV_CAUSE where a_lemma= 'grow' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- cause
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=grow&i=7&h=0001000000000000#c

select * from MV_ANTONYM where a_lemma= 'upstage' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- antonym
---- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=upstage&i=10&h=00001100100#c

select * from MV_SIMILAR_TO where a_lemma= 'upstage' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- Similar to
---- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=upstage&i=6&h=0000010000#c

select * from MV_ALSO where a_lemma= 'abundant' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- also or see also
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=abundant&i=1&h=100000#c

select * from MV_PHRASAL_VERB where a_lemma= 'fight' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
---- also or phrasal verb
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=fight&i=8&h=00000100000000#c

select * from MV_ATTRIBUTE where a_lemma= 'orient' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- attribute
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=orient&i=2&h=10000000000#c

select * from MV_VERB_GROUP where a_lemma= 'action' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- verb group
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=action&i=19&h=00000000001100000100000#c

select * from MV_PARTICIPLE where a_lemma= 'sought' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- participle
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=sought&i=6&h=00000100#c

select * from MV_PERTAINYM where a_lemma= 'aortic' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- pertainym
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=aortic&i=1&h=100#c

select * from MV_DERIVATION where a_lemma= 'gabble' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- Derivation or derivationally related form
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=gabble&i=8&h=1010010000#c

select * from MV_DOMAIN_CATEGORY where a_lemma= 'upstage' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- domain category
---- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=upstage&i=7&h=000000100#c

select * from MV_DOMAIN_MEMBER_CATEGORY where a_lemma= 'physics' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
-- domain member category or domain term category
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=physics&i=3&h=0100000#c

select * from MV_DOMAIN_REGION where a_lemma= 'humanitarian' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
-- domain region
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=humanitarian&i=4&h=00100000#c

select * from MV_DOMAIN_MEMBER_REGION where a_lemma= 'mexico' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
-- domain member region or domain term region
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=mexico&i=1&h=10000000#c

select * from MV_DOMAIN_USAGE where a_lemma= 'stinky' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
-- domain usage
---- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=stinky&i=2&h=010000#c

select * from MV_DOMAIN_MEMBER_USAGE where a_lemma= 'patois' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
-- domain member usage or domain term usage
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=patois&i=2&h=100000#c

select * from MV_HAS_INSTANCE_HYPONYM where a_lemma= 'fight' order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum;
--- has instance hyponym or has instance
--- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=fight&i=3&h=100000000000000#c

--------------------------------------------------------------------------------------------------------------------------
--- Sentence frames of verbs
--- this is not a SEMANTIC RELATION

select * from MV_SENTENCE_FRAME where lemma = 'fight' order by synsetid;
---- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=fight&i=34&h=00000100001000001000100010001010000#c

--------------------------------------------------------------------------------------------------------------------------
--- A unified view that contains all relations
--- MV_ALL_LINKS

SELECT *
FROM MV_ALL_LINKS WHERE A_LEMMA='java'
order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum, 
INSTR('x94,x2,x13,x12,x14,x91,x32,x16,x92,x96,x15,x70,x1,x11,x23,x93,x4,x3,x21,x50,x95,x40,x60,x71,x30,x80,x81,' ,'x'||B_LINKID||',');
---- http://wordnetweb.princeton.edu/perl/webwn?o2=1&o0=1&o8=1&o1=1&o7=1&o5=1&o9=&o6=1&o3=&o4=1&s=java&i=34&h=11000101010101100000000000001001010#c

SELECT A_LEMMA,   A_POS,   A_DEFINITION,  D_LINK,  C_POS,  C_HIDEALL,  C_DEFINITION FROM MV_ALL_LINKS WHERE A_LEMMA='java' 
order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum, 
INSTR('x94,x2,x13,x12,x14,x91,x32,x16,x92,x96,x15,x70,x1,x11,x23,x93,x4,x3,x21,x50,x95,x40,x60,x71,x30,x80,x81,' ,'x'||B_LINKID||',');

SELECT A_LEMMA,   A_POS,   A_DEFINITION,  D_LINK,  C_POS,  C_HIDEALL,  C_DEFINITION FROM MV_ALL_LINKS WHERE A_LEMMA='upstage'
order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum, 
INSTR('x94,x2,x13,x12,x14,x91,x32,x16,x92,x96,x15,x70,x1,x11,x23,x93,x4,x3,x21,x50,x95,x40,x60,x71,x30,x80,x81,' ,'x'||B_LINKID||',');

SELECT *
FROM MV_ALL_LINKS WHERE A_LEMMA='upstage'
order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum, 
INSTR('x94,x2,x13,x12,x14,x91,x32,x16,x92,x96,x15,x70,x1,x11,x23,x93,x4,x3,x21,x50,x95,x40,x60,x71,x30,x80,x81,' ,'x'||B_LINKID||',');

SELECT *
FROM MV_ALL_LINKS WHERE A_LEMMA='chile'
order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum, 
INSTR('x94,x2,x13,x12,x14,x91,x32,x16,x92,x96,x15,x70,x1,x11,x23,x93,x4,x3,x21,x50,x95,x40,x60,x71,x30,x80,x81,' ,'x'||B_LINKID||',');

SELECT *
FROM MV_ALL_LINKS WHERE A_LEMMA='arithmetic'
order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum, 
INSTR('x94,x2,x13,x12,x14,x91,x32,x16,x92,x96,x15,x70,x1,x11,x23,x93,x4,x3,x21,x50,x95,x40,x60,x71,x30,x80,x81,' ,'x'||B_LINKID||',');

SELECT *
FROM MV_ALL_LINKS WHERE A_LEMMA='many'
order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum, 
INSTR('x94,x2,x13,x12,x14,x91,x32,x16,x92,x96,x15,x70,x1,x11,x23,x93,x4,x3,x21,x50,x95,x40,x60,x71,x30,x80,x81,' ,'x'||B_LINKID||',');

SELECT *
FROM MV_ALL_LINKS WHERE A_LEMMA='fight'
order by INSTR('n,v,a,s,r,' , a_pos||',') , a_sensenum, 
INSTR('x94,x2,x13,x12,x14,x91,x32,x16,x92,x96,x15,x70,x1,x11,x23,x93,x4,x3,x21,x50,x95,x40,x60,x71,x30,x80,x81,' ,'x'||B_LINKID||',');

---------------------------------------------------------------------------------------------------------------------
--- inherited hypernymns of coffee
--- http://wordnetweb.princeton.edu/perl/webwn?o2=&o0=&o8=1&o1=&o7=&o5=&o9=&o6=&o3=&o4=&r=1&s=coffee&i=3&h=1000000#c
select  distinct A_HIDEALL, C_HIDEALL, C_SYNSETID from MV_DIRECT_HYPERNYM where A_SYNSETID=107860414;
select  distinct A_HIDEALL, C_HIDEALL, C_SYNSETID from MV_DIRECT_HYPERNYM where A_SYNSETID=107812430;
select  distinct A_HIDEALL, C_HIDEALL, C_SYNSETID from MV_DIRECT_HYPERNYM where A_SYNSETID=100021445;

-----------------------------------------------------------------------------------
Query to illustrate Wordnet for NLP as a source for disambiguation


select A_LEXDOMAINNAME, A_SHOWALL, A_DEFINITION, C_SHOWALL from MV_DIRECT_HYPONYM where a_lemma='bank' ;


--------------------------------------------------------------------------------------------------------------------------
--- Queries to illustrate semantic distance between words
select  distinct A_HIDEALL, C_HIDEALL, C_SYNSETID from MV_DIRECT_HYPERNYM where A_LEMMA= 'java' and A_SYNSETID=107860414;
select  distinct A_HIDEALL, C_HIDEALL, C_SYNSETID from MV_DIRECT_HYPERNYM where A_SYNSETID=107812430;
select  distinct A_HIDEALL, C_HIDEALL, C_SYNSETID from MV_DIRECT_HYPERNYM where A_SYNSETID=100021445;


-----------------------------------------------------------------------------------
--- A table that contains inflected forms of words
---  MORPHOLOGY

SELECT *  FROM MORPHOLOGY WHERE MORPH in ('quizzes', 'men', 'best','wolves') order by morph;

SELECT *  FROM MORPHOLOGY WHERE LEMMA in ('good', 'well',  'man', 'quiz', 'wolf') order by morph;

--------------------------------------------------------------------------------------------------------------------------
--- Materialized view customized for a specific Word Games such as  Hangaroo and Hangman
-- MV_HANGGAMES

SELECT * FROM  MV_HANGGAMES WHERE lemma in ('introjection', 'delphic oracle', 'expansion slot', 'user interface', 'technical foul', 'topicalization');

--------------------------------------------------------------------------------------------------------------------------
--- Stored functions for Word Games
select sf_cnt_in_set_ratio( 'abecd', 'aeiouAEIOU ') from dual;

select sf_cnt_not_in_set_consecutive( 'abecdfgha', 'aeiouAEIOU-/.'' ') from dual;

select sf_excluding_chars('abcd', '0123456789') from dual;

select SF_STR_LEN ('ab cde-g') from dual;

---- Sample Difficult Words
select category, lemma, definition from  MV_HANGGAMES where 
sf_excluding_chars(lemma, '0123456789')=1
and SF_STR_LEN(lemma)> 9
and sf_cnt_in_set_ratio(lemma, 'aeiouAEIOU ') < 0.2
and sf_cnt_not_in_set_consecutive( lemma, 'aeiouAEIOU-/.'' ') = 5;
--------------------------------------------------------------------------------------------------------









