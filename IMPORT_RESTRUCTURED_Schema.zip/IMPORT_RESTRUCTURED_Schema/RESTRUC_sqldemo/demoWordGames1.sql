
--- Hangaroo Content from MV_HANGGAMES 
select count(*)/5 from mv_hanggames where subcategory is not null and
sf_excluding_chars(lemma, '0123456789/') = 1  and SF_STR_LEN(lemma)>3;
--- 972
--- the number of rows per difficulty level should be more less the same with this value

select lemma, subcategory, category, definition from mv_hanggames
where  subcategory is not null and
sf_excluding_chars(lemma, '0123456789/') = 1  and SF_STR_LEN(lemma)>4
and POLYSEMY_CNT >3;
-- level 1
--- easiest level

select count(*) from mv_hanggames
where  subcategory is not null and
sf_excluding_chars(lemma, '0123456789/') = 1  and SF_STR_LEN(lemma)>4
and POLYSEMY_CNT > 3;
-- level 1
--- 729

select lemma, subcategory, category, definition from mv_hanggames
where  subcategory is not null and
sf_excluding_chars(lemma, '0123456789/') = 1  and SF_STR_LEN(lemma)>4
and POLYSEMY_CNT <=3
and sf_cnt_in_set_ratio(lemma, 'aeiouAEIOU ') >=0.429
-- level 2
--- 1013

select lemma, subcategory, category, definition from mv_hanggames
where  subcategory is not null and
sf_excluding_chars(lemma, '0123456789/') = 1  and SF_STR_LEN(lemma)>4
and POLYSEMY_CNT <=3
and sf_cnt_in_set_ratio(lemma, 'aeiouAEIOU ') < 0.429 and  sf_cnt_in_set_ratio(lemma, 'aeiouAEIOU ') >= 0.4
-- level 3

select count(*) from mv_hanggames
where  subcategory is not null and
sf_excluding_chars(lemma, '0123456789/') = 1  and SF_STR_LEN(lemma)>4
and POLYSEMY_CNT <=3
and sf_cnt_in_set_ratio(lemma, 'aeiouAEIOU ') < 0.429 and  sf_cnt_in_set_ratio(lemma, 'aeiouAEIOU ') >= 0.4
-- level 3
-- 902

select lemma, subcategory, category, definition from mv_hanggames
where  subcategory is not null and
sf_excluding_chars(lemma, '0123456789/') = 1  and SF_STR_LEN(lemma)>4
and POLYSEMY_CNT <=3
and sf_cnt_in_set_ratio(lemma, 'aeiouAEIOU ') < 0.4
and sf_cnt_not_in_set_consecutive( lemma, 'aeiouAEIOU-/.'' ') <= 2
-- level 4

select count(*) from mv_hanggames
where  subcategory is not null and
sf_excluding_chars(lemma, '0123456789/') = 1  and SF_STR_LEN(lemma)>4
and POLYSEMY_CNT <=3
and sf_cnt_in_set_ratio(lemma, 'aeiouAEIOU ') < 0.4
and sf_cnt_not_in_set_consecutive( lemma, 'aeiouAEIOU-/.'' ') <= 2
-- level 4
-- 1056

select lemma, subcategory, category, definition from mv_hanggames
where  subcategory is not null and
sf_excluding_chars(lemma, '0123456789/') = 1  and SF_STR_LEN(lemma)>4
and POLYSEMY_CNT =1
and sf_cnt_in_set_ratio(lemma, 'aeiouAEIOU ') < 0.3
and sf_cnt_not_in_set_consecutive( lemma, 'aeiouAEIOU-/.'' ')>2
-- level 5
--- most difficult level

select count(*) from mv_hanggames
where  subcategory is not null and
sf_excluding_chars(lemma, '0123456789/') = 1  and SF_STR_LEN(lemma)>4
and POLYSEMY_CNT =1
and sf_cnt_in_set_ratio(lemma, 'aeiouAEIOU ') < 0.3
and sf_cnt_not_in_set_consecutive( lemma, 'aeiouAEIOU-/.'' ')>2
-- level 5
-- 201

-------------------------------------------------------------------------------------------
--- In this project, there are 3 tables that are identified to provide content for Hangman content
--- Namely, MV_INSTANCE_HYPONYM, MV_HANGGAMES, SEARCH_WORDNET

---- Hangman content from  MV_INSTANCE_HYPONYM table
select a_synsetid, a_lemma, a_lexdomainname, a_pos, a_hideall,  c_lexdomainname, c_pos, c_hideall from MV_INSTANCE_HYPONYM
where c_hideall like '%country%' and a_lemma not like '% %'
order by  a_synsetid;
--- countries

select  a_lemma, a_lexdomainname, a_pos, a_hideall,  c_lexdomainname, c_pos, c_hideall from MV_INSTANCE_HYPONYM
where c_hideall like '%composer%';
--- composers

select  a_lemma, a_lexdomainname, a_pos, a_hideall,  c_lexdomainname, c_pos, c_hideall from mv_instance_hyponym 
where c_hideall like '%actress%';
--- actress

select  a_lemma, a_lexdomainname, a_pos, a_hideall,  c_lexdomainname, c_pos, c_hideall from mv_instance_hyponym 
where c_hideall like '%chemist%';

select  a_lemma, a_lexdomainname, a_pos, a_hideall,  c_lexdomainname, c_pos, c_hideall from mv_instance_hyponym 
where c_hideall like '%dictator%';

select  a_lemma, a_lexdomainname, a_pos, a_hideall,  c_lexdomainname, c_pos, c_hideall from mv_instance_hyponym 
where c_hideall like '%fictional character%';

select  a_lemma, a_lexdomainname, a_pos, a_hideall,  c_lexdomainname, c_pos, c_hideall from mv_instance_hyponym 
where c_hideall like '%constellation%';

select  a_lemma, a_lexdomainname, a_pos, a_hideall,  c_lexdomainname, c_pos, c_hideall from mv_instance_hyponym 
where c_hideall like '%pianist%';

----Hangman content from  MV_HANGGAMES table
select subcategory, count(*) WORDCOUNT from mv_hanggames where subcategory is not null group by subcategory 
having count(*)>=10 order by count(*);
--- word count per Hangman category

select distinct lemma from mv_hanggames where subcategory = 'basketball';
--- basketball

select distinct lemma from mv_hanggames where subcategory = 'astrology' order by lemma;
--- astrology


----Hangman content from SEARCH_WORDNET table
select lexdomainname, count(*) wordcount from SEARCH_WORDNET group by lexdomainname order by count(*);
---- http://wordnet.princeton.edu/wordnet/man/lexnames.5WN.html
---- Some categories here can be used in Hangman

select distinct lemma from SEARCH_WORDNET where lexdomainname='verb.weather' order by lemma;
---------------------------------------------------------------------------------------------
--- Boggle and Scrabble

select * from  mv_wordnet_scrabble where lemma='prep';

select * from  mv_wordnet_scrabble where lemma='pre';
-- but this word is a valid word in National Scrabble Association

select * from  mv_wordnet_scrabble where lemma in ('lincoln', 'daniel');
-- proper nouns are excluded just like the standard Scrabble.

----------------------------------------------------------------------------------------------------------------
---- batang henyo
select * from POSTYPES;
select  LEXDOMAINNAME from LEXDOMAINS where pos='n';

--- location is divided into: eastern hemisphere abd western hemisphere
select distinct b.a_lemma from MV_PART_MERONYM a join MV_PART_MERONYM b on a.c_synsetid=b.a_synsetid where a.A_LEMMA = 'eastern hemisphere';
select distinct b.a_lemma from MV_PART_MERONYM a join MV_PART_MERONYM b on a.c_synsetid=b.a_synsetid where a.A_LEMMA = 'eurasia';
select distinct b.a_lemma from MV_PART_MERONYM a join MV_PART_MERONYM b on a.c_synsetid=b.a_synsetid where a.A_LEMMA = 'asia';
select distinct b.a_lemma from MV_PART_MERONYM a join MV_PART_MERONYM b on a.c_synsetid=b.a_synsetid where a.A_LEMMA = 'southeast asia';
select distinct b.a_lemma from MV_PART_MERONYM a join MV_PART_MERONYM b on a.c_synsetid=b.a_synsetid where a.A_LEMMA = 'indonesia';













