EXEC DBMS_UTILITY.compile_schema(schema => 'RESTRUC_WORDNET3');
exit;
